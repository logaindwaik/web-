from django.urls import path
from . import views
urlpatterns = [
    path('register/',views.signup),
    path('login/',views.signin),
    path('logout/',views.logout),
    path('home/',views.search),
    path('my-courses/',views.myCourses),
    path('register-course/<int:pk>',views.register_course),
    path('course/<int:pk>',views.course),
    path('remove/<int:pk>',views.remove_course),
]
